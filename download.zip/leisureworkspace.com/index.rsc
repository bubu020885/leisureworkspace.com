2:I["8c0f216c4604",[],"Children",1]
3:I["958b29d28ee2",[],"AnalyticsConsent",1]
4:I["15c18cfaeeff",[],"LayoutSegmentProvider",1]
5:I["8c0f216c4604",[],"Slot",1]
6:I["593f344dc510",[],"RedirectBoundary",1]
:HL["/assets/index-BP5Wovhu.css","style"]
0:{"__route":"route:/","__interceptionContext":null,"__layoutIds":["layout:/"],"__rootLayout":"/","page:/":"$L1","layout:/":[[[["$","link","css:/assets/index-BP5Wovhu.css",{"rel":"stylesheet","precedence":"vite-rsc/importer-resources","href":"/assets/index-BP5Wovhu.css","data-rsc-css-href":"/assets/index-BP5Wovhu.css"}],"$undefined"],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"antialiased","children":[["$","$L2",null,{}],["$","$L3",null,{}]]}]}]],null],"route:/":[[["$","meta",null,{"charSet":"utf-8"}],[["$","title","0",{"children":"Leisure Workspace"}],["$","meta","1",{"name":"description","content":"Plan better. Decide faster. Practical business planning, budget and customer journey tools for leisure attractions. Presented by Amusement Business Support."}],["$","link","2",{"rel":"shortcut icon","href":"/clipboard-favicon-v2.svg"}],["$","link","3",{"rel":"icon","href":"/clipboard-favicon-v2.svg"}]],[["$","meta","0",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]],["$","$L4",null,{"segmentMap":{"children":[]},"children":["$","$L5",null,{"id":"layout:/","parallelSlots":"$undefined","children":["$","$L6",null,{"children":["$","$L4",null,{"segmentMap":{"children":[]},"children":["$","$L5",null,{"id":"page:/"}]}]}]}]}]],"__layoutFlags":{"layout:/":"s"},"__artifactCompatibility":{"schemaVersion":1,"graphVersion":"app-route-graph:4uhn5s1wvoptc","deploymentVersion":"94b9aa78-41d4-4f7e-98ee-6247a46e2c27","appElementsSchemaVersion":1,"rscPayloadSchemaVersion":1,"rootBoundaryId":"/","renderEpoch":null}}
7:I["6efdf509a785",[],"default",1]
1:["$","$L7",null,{"params":"$@8","searchParams":"$@9"}]
8:{}
9:{}
